package com.projetandroid.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class profil extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pageprofil);
    }

    public void onClick6(View v) {
        if (v != null && v.getId() == R.id.fleche) {
            Intent intent = new Intent(this, accueil.class);
            startActivity(intent);
        }
    }
    public void onClick7(View v) {
        if (v.getId() == R.id.deconnecter) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }
}



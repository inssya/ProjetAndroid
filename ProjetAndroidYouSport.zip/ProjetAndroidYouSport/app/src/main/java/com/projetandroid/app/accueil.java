package com.projetandroid.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class accueil extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pageaccueil);
    }

    //clique vers liste evenement
    public void onClick4(View v) {
        if (v != null && v.getId() == R.id.button2) {
            Intent intent = new Intent(this, listeevenement.class);
            startActivity(intent);
        }}
    //clique vers page profil
    public void onClick8(View v) {
        if (v.getId() == R.id.accountButton) {
            Intent intent = new Intent(this, profil.class);
            startActivity(intent);
        }}
    //clique vers page notification
        public void onClick10(View v) {
            if (v.getId() == R.id.notificationsButton) {
                Intent intent = new Intent(this, notifications.class);
                startActivity(intent);
            }

    }
}

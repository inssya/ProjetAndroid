package com.projetandroid.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    //creation d'activité et definition du layout
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        //onClick + definition du click en mentionnant le nom du boutton
        if (v != null && v.getId() == R.id.boutton1) {
            //intention de passer a la page de connexion
                    Intent intent = new Intent(this, connexion.class);
                    startActivity(intent);
            }
    }
}
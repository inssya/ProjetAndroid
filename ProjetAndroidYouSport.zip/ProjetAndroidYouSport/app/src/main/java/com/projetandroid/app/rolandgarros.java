package com.projetandroid.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class rolandgarros extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.evenement);
        Button boutonRedirection = findViewById(R.id.button);
        // Ajouter un click pour le bouton
        boutonRedirection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // URL du site internet à rediriger
                String url = "https://tickets.rolandgarros.com/fr#xtor=AD-3-[rgow_2023]-[FR]-[popin_abtasty]-[rolandgarros.com]-";

                // Créer une intention pour ouvrir le navigateur avec l'URL
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
    }
}
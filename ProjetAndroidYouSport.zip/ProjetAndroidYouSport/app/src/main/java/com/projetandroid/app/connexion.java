package com.projetandroid.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class connexion extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pageconnexion);
    }
    public void onClick1(View v) {
        //onClick1 > boutton "se connecter"
        if (v.getId() == R.id.button) {
            //intention de passer à la page d'accueil
            Intent intent = new Intent(this, accueil.class);
            startActivity(intent);
        }
    }
    public void onClick3(View v) {
        //onClick3 > boutton "inscrivez-vous "
        if (v.getId() == R.id.button3) {
            //intention de passer à la page d'accueil
            Intent intent = new Intent(this, creercompte.class);
            startActivity(intent);
        }
    }


}

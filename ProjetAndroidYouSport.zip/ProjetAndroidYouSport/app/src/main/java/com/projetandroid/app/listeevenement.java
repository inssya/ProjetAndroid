package com.projetandroid.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class listeevenement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listeevenement);
    }
    //clique vers evenement roland garros
    public void onClick5(View v) {
        if (v != null && v.getId() == R.id.button10) {
            Intent intent = new Intent(this, rolandgarros.class);
            startActivity(intent);
        }
    }}